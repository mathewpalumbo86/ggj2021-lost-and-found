﻿using UnityEngine;

[System.Serializable]
public class VertexColor : ScriptableObject
{
    public Color[] colors = null;
}
